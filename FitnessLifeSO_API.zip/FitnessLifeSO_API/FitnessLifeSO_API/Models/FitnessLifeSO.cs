using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace FitnessLifeSO_API.Models
{
    public partial class FitnessLifeSO : DbContext
    {
        public FitnessLifeSO()
            : base("name=FitnessLifeSO")
        {
        }

        public virtual DbSet<C__MigrationHistory> C__MigrationHistory { get; set; }
        public virtual DbSet<AspNetRoles> AspNetRoles { get; set; }
        public virtual DbSet<AspNetUserClaims> AspNetUserClaims { get; set; }
        public virtual DbSet<AspNetUserLogins> AspNetUserLogins { get; set; }
        public virtual DbSet<AspNetUsers> AspNetUsers { get; set; }
        public virtual DbSet<DietaDetalles> DietaDetalles { get; set; }
        public virtual DbSet<Dietas> Dietas { get; set; }
        public virtual DbSet<RutinaDetalles> RutinaDetalles { get; set; }
        public virtual DbSet<Rutinas> Rutinas { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AspNetRoles>()
                .HasMany(e => e.AspNetUsers)
                .WithMany(e => e.AspNetRoles)
                .Map(m => m.ToTable("AspNetUserRoles").MapLeftKey("RoleId").MapRightKey("UserId"));

            modelBuilder.Entity<AspNetUsers>()
                .HasMany(e => e.AspNetUserClaims)
                .WithRequired(e => e.AspNetUsers)
                .HasForeignKey(e => e.UserId);

            modelBuilder.Entity<AspNetUsers>()
                .HasMany(e => e.AspNetUserLogins)
                .WithRequired(e => e.AspNetUsers)
                .HasForeignKey(e => e.UserId);

            modelBuilder.Entity<Dietas>()
                .HasMany(e => e.DietaDetalles)
                .WithRequired(e => e.Dietas)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Rutinas>()
                .HasMany(e => e.RutinaDetalles)
                .WithRequired(e => e.Rutinas)
                .WillCascadeOnDelete(false);
        }
    }
}
