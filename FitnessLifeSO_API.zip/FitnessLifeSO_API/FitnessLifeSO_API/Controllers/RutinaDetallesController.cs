﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using FitnessLifeSO_API.Models;

namespace FitnessLifeSO_API.Controllers
{
    public class RutinaDetallesController : ApiController
    {
        private FitnessLifeSO db = new FitnessLifeSO();

        // GET: api/RutinaDetalles
        public IQueryable<RutinaDetalles> GetRutinaDetalles()
        {
            return db.RutinaDetalles;
        }

        // GET: api/RutinaDetalles/5
        [ResponseType(typeof(RutinaDetalles))]
        public IHttpActionResult GetRutinaDetalles(int id)
        {
            RutinaDetalles rutinaDetalles = db.RutinaDetalles.Find(id);
            if (rutinaDetalles == null)
            {
                return NotFound();
            }

            return Ok(rutinaDetalles);
        }

        // PUT: api/RutinaDetalles/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutRutinaDetalles(int id, RutinaDetalles rutinaDetalles)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != rutinaDetalles.IdRutinaDetalle)
            {
                return BadRequest();
            }

            db.Entry(rutinaDetalles).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RutinaDetallesExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/RutinaDetalles
        [ResponseType(typeof(RutinaDetalles))]
        public IHttpActionResult PostRutinaDetalles(RutinaDetalles rutinaDetalles)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.RutinaDetalles.Add(rutinaDetalles);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = rutinaDetalles.IdRutinaDetalle }, rutinaDetalles);
        }

        // DELETE: api/RutinaDetalles/5
        [ResponseType(typeof(RutinaDetalles))]
        public IHttpActionResult DeleteRutinaDetalles(int id)
        {
            RutinaDetalles rutinaDetalles = db.RutinaDetalles.Find(id);
            if (rutinaDetalles == null)
            {
                return NotFound();
            }

            db.RutinaDetalles.Remove(rutinaDetalles);
            db.SaveChanges();

            return Ok(rutinaDetalles);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool RutinaDetallesExists(int id)
        {
            return db.RutinaDetalles.Count(e => e.IdRutinaDetalle == id) > 0;
        }
    }
}