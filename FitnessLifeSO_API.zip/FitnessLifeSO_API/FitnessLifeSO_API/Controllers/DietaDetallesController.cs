﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using FitnessLifeSO_API.Models;

namespace FitnessLifeSO_API.Controllers
{
    public class DietaDetallesController : ApiController
    {
        private FitnessLifeSO db = new FitnessLifeSO();

        // GET: api/DietaDetalles
        public IQueryable<DietaDetalles> GetDietaDetalles()
        {
            return db.DietaDetalles;
        }

        // GET: api/DietaDetalles/5
        [ResponseType(typeof(DietaDetalles))]
        public IHttpActionResult GetDietaDetalles(int id)
        {
            DietaDetalles dietaDetalles = db.DietaDetalles.Find(id);
            if (dietaDetalles == null)
            {
                return NotFound();
            }

            return Ok(dietaDetalles);
        }

        // PUT: api/DietaDetalles/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutDietaDetalles(int id, DietaDetalles dietaDetalles)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != dietaDetalles.IdDietaDetalle)
            {
                return BadRequest();
            }

            db.Entry(dietaDetalles).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DietaDetallesExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/DietaDetalles
        [ResponseType(typeof(DietaDetalles))]
        public IHttpActionResult PostDietaDetalles(DietaDetalles dietaDetalles)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.DietaDetalles.Add(dietaDetalles);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = dietaDetalles.IdDietaDetalle }, dietaDetalles);
        }

        // DELETE: api/DietaDetalles/5
        [ResponseType(typeof(DietaDetalles))]
        public IHttpActionResult DeleteDietaDetalles(int id)
        {
            DietaDetalles dietaDetalles = db.DietaDetalles.Find(id);
            if (dietaDetalles == null)
            {
                return NotFound();
            }

            db.DietaDetalles.Remove(dietaDetalles);
            db.SaveChanges();

            return Ok(dietaDetalles);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool DietaDetallesExists(int id)
        {
            return db.DietaDetalles.Count(e => e.IdDietaDetalle == id) > 0;
        }
    }
}