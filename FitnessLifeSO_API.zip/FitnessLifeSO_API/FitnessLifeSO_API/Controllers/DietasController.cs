﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using FitnessLifeSO_API.Models;

namespace FitnessLifeSO_API.Controllers
{
    public class DietasController : ApiController
    {
        private FitnessLifeSO db = new FitnessLifeSO();

        // GET: api/Dietas
        public IQueryable<Dietas> GetDietas()
        {
            return db.Dietas;
        }

        // GET: api/Dietas/5
        [ResponseType(typeof(Dietas))]
        public IHttpActionResult GetDietas(int id)
        {
            Dietas dietas = db.Dietas.Find(id);
            if (dietas == null)
            {
                return NotFound();
            }

            return Ok(dietas);
        }

        // PUT: api/Dietas/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutDietas(int id, Dietas dietas)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != dietas.IdDieta)
            {
                return BadRequest();
            }

            db.Entry(dietas).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DietasExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Dietas
        [ResponseType(typeof(Dietas))]
        public IHttpActionResult PostDietas(Dietas dietas)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Dietas.Add(dietas);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = dietas.IdDieta }, dietas);
        }

        // DELETE: api/Dietas/5
        [ResponseType(typeof(Dietas))]
        public IHttpActionResult DeleteDietas(int id)
        {
            Dietas dietas = db.Dietas.Find(id);
            if (dietas == null)
            {
                return NotFound();
            }

            db.Dietas.Remove(dietas);
            db.SaveChanges();

            return Ok(dietas);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool DietasExists(int id)
        {
            return db.Dietas.Count(e => e.IdDieta == id) > 0;
        }
    }
}