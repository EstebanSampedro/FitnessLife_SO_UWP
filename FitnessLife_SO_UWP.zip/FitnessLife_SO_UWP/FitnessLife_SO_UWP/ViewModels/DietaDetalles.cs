﻿using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.Toolkit.Mvvm.ComponentModel;

namespace FitnessLife_SO_UWP.ViewModels
{
    public class DietaDetalles : ObservableObject
    {
        [Key]
        public int IdDietaDetalle { get; set; }

        [Required]
        public string DiaSemana { get; set; }

        [Required]
        public string HoraComida { get; set; }

        [Required]
        public string Plato { get; set; }

        [Required]
        public string Porcion { get; set; }

        public string ImagePath { get; set; }

        public int IdDieta { get; set; }

        public virtual Dietas Dietas { get; set; }

        public DietaDetalles()
        {
        }
    }
}
