﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.Toolkit.Mvvm.ComponentModel;

namespace FitnessLife_SO_UWP.ViewModels
{
    public class Rutinas : ObservableObject
    {
        
        [Key]
        public int IdRutina { get; set; }

        [Required]
        public string Descripcion { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<RutinaDetalles> RutinaDetalles { get; set; }
        public Rutinas()
        {
        }
    }
}
