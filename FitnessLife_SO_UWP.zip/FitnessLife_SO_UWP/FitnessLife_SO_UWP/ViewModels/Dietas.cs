﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.Toolkit.Mvvm.ComponentModel;

namespace FitnessLife_SO_UWP.ViewModels
{
    public class Dietas : ObservableObject
    {
        [Key]
        public int IdDieta { get; set; }

        [Required]
        public string Descripcion { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<DietaDetalles> DietaDetalles { get; set; }
        public Dietas()
        {
        }
    }
}
