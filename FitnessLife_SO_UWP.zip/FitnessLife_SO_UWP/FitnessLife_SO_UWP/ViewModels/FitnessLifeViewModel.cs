﻿using System;

using Microsoft.Toolkit.Mvvm.ComponentModel;

namespace FitnessLife_SO_UWP.ViewModels
{
    public class FitnessLifeViewModel : ObservableObject
    {
        public FitnessLifeViewModel()
        {
        }
    }
}
