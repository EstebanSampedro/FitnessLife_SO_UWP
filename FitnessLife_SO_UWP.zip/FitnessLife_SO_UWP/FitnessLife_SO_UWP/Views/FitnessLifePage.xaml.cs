﻿using System;

using FitnessLife_SO_UWP.ViewModels;

using Windows.UI.Xaml.Controls;

namespace FitnessLife_SO_UWP.Views
{
    public sealed partial class FitnessLifePage : Page
    {
        public FitnessLifeViewModel ViewModel { get; } = new FitnessLifeViewModel();

        public FitnessLifePage()
        {
            InitializeComponent();
        }

        private void FlipView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
