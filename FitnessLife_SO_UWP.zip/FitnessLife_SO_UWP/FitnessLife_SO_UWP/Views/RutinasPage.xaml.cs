﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using FitnessLife_SO_UWP.ViewModels;
using FitnessLife_SO_UWP.Views.RutinaViews;
using Newtonsoft.Json;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace FitnessLife_SO_UWP.Views
{
    public sealed partial class RutinasPage : Page
    {
        public Rutinas ViewModel { get; } = new Rutinas();

        public RutinasPage()
        {
            InitializeComponent();
        }

        //private async void Button_Click(object sender, RoutedEventArgs e)
        //{
            

        //}

        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
          
            await mostrarDatos();
            
        }

        public async Task mostrarDatos()
        {
            var httpHandler = new HttpClientHandler();
            var request = new HttpRequestMessage();
            request.RequestUri = new Uri("https://localhost:44396/api/rutinas");
            request.Method = HttpMethod.Get;
            request.Headers.Add("accept", "application/json");

            var client = new HttpClient(httpHandler);

            HttpResponseMessage response = await client.SendAsync(request);

            string content = await response.Content.ReadAsStringAsync();
            var resultado = JsonConvert.DeserializeObject<List<Rutinas>>(content);
            Lista.ItemsSource = resultado;

        }


        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            switch ((sender as Button).Content.ToString())

            {

                case "Crear":

                    Frame.Content = null;
                    Frame.Navigate(typeof(CrearRutina));

                    break;

                case "Modificar":

                    Rutinas modificarRutina = (Rutinas)Lista.SelectedItem;
                    if (modificarRutina != null)
                    {
                        modificarRutina.RutinaDetalles = null;
                        Frame.Content = null;
                        Frame.Navigate(typeof(ModificarRutina), modificarRutina.IdRutina);
                    }

                    break;

                case "Eliminar":

                    Rutinas eliminarRutina = (Rutinas)Lista.SelectedItem;
                    if (eliminarRutina != null)
                    {
                        eliminarRutina.RutinaDetalles = null;
                        var httpHandler = new HttpClientHandler();
                        var client = new HttpClient(httpHandler);
                        var json = JsonConvert.SerializeObject(eliminarRutina);
                        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
                        HttpResponseMessage response = await client.DeleteAsync($"https://localhost:44396/api/rutinas/{eliminarRutina.IdRutina}");
                        Frame.Content = null;
                        Frame.Navigate(typeof(RutinasPage));

                    }

                    break;

                default:

                    break;

            }
        }
    }
}
