﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using FitnessLife_SO_UWP.ViewModels;
using FitnessLife_SO_UWP.Views.DietaViews;
using Newtonsoft.Json;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace FitnessLife_SO_UWP.Views
{
    public sealed partial class DietasPage : Page
    {
        public Dietas ViewModel { get; } = new Dietas();

        public DietasPage()
        {
            InitializeComponent();
        }
        

        //}
        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
            await mostrarDatos();
            
        }

        public async Task mostrarDatos()
        {
            var httpHandler = new HttpClientHandler();
            var request = new HttpRequestMessage();
            request.RequestUri = new Uri("https://localhost:44396/api/dietas");
            request.Method = HttpMethod.Get;
            request.Headers.Add("accept", "application/json");

            var client = new HttpClient(httpHandler);

            HttpResponseMessage response = await client.SendAsync(request);

            string content = await response.Content.ReadAsStringAsync();
            var resultado = JsonConvert.DeserializeObject<List<Dietas>>(content);
            Lista.ItemsSource = resultado;

        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            switch ((sender as Button).Content.ToString())

            {

                case "Crear":

                    Frame.Content = null;
                    Frame.Navigate(typeof(CrearDieta));

                    break;

                case "Modificar":

                    Dietas modificarDieta = (Dietas)Lista.SelectedItem;
                    if (modificarDieta != null)
                    {
                        modificarDieta.DietaDetalles = null;
                        Frame.Content = null;
                        Frame.Navigate(typeof(ModificarDieta), modificarDieta.IdDieta);
                    }

                    break;

                case "Eliminar":

                    Dietas eliminarDieta = (Dietas)Lista.SelectedItem;
                    if (eliminarDieta != null)
                    {
                        eliminarDieta.DietaDetalles = null;
                        var httpHandler = new HttpClientHandler();
                        var client = new HttpClient(httpHandler);
                        var json = JsonConvert.SerializeObject(eliminarDieta);
                        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
                        HttpResponseMessage response = await client.DeleteAsync($"https://localhost:44396/api/dietas/{eliminarDieta.IdDieta}");
                        Frame.Content = null;
                        Frame.Navigate(typeof(DietasPage));

                    }

                    break;

                default:

                    break;

            }

        }
    }
}
