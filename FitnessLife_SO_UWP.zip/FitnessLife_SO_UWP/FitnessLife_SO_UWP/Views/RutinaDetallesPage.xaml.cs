﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using FitnessLife_SO_UWP.ViewModels;
using FitnessLife_SO_UWP.Views.RutinaDetallesViews;
using Newtonsoft.Json;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace FitnessLife_SO_UWP.Views
{
    public sealed partial class RutinaDetallesPage : Page
    {
        public RutinaDetalles ViewModel { get; } = new RutinaDetalles();

        public RutinaDetallesPage()
        {
            InitializeComponent();
        }
        

        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
            await mostrarDatos();
        }

        

        public async Task mostrarDatos()
        {
            var httpHandler = new HttpClientHandler();
            var request = new HttpRequestMessage();
            request.RequestUri = new Uri("https://localhost:44396/api/rutinadetalles");
            request.Method = HttpMethod.Get;
            request.Headers.Add("accept", "application/json");

            var client = new HttpClient(httpHandler);

            HttpResponseMessage response = await client.SendAsync(request);

            string content = await response.Content.ReadAsStringAsync();
            var resultado = JsonConvert.DeserializeObject<List<RutinaDetalles>>(content);
            Lista.ItemsSource = resultado;

        }



        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            switch ((sender as Button).Content.ToString())

            {

                case "Crear":

                    Frame.Content = null;
                    Frame.Navigate(typeof(CrearRutinaDetalles));

                    break;

                case "Modificar":

                    RutinaDetalles modificarRutinaDetalles = (RutinaDetalles)Lista.SelectedItem;
                    if (modificarRutinaDetalles != null)
                    {
                        modificarRutinaDetalles.Rutinas = null;
                        Frame.Content = null;
                        Frame.Navigate(typeof(ModificarRutinaDetalles), modificarRutinaDetalles.IdRutinaDetalle);
                    }

                    break;

                case "Eliminar":

                    RutinaDetalles eliminarRutinaDetalles = (RutinaDetalles)Lista.SelectedItem;
                    if (eliminarRutinaDetalles != null)
                    {
                        eliminarRutinaDetalles.Rutinas = null;
                        var httpHandler = new HttpClientHandler();
                        var client = new HttpClient(httpHandler);
                        var json = JsonConvert.SerializeObject(eliminarRutinaDetalles);
                        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
                        HttpResponseMessage response = await client.DeleteAsync($"https://localhost:44396/api/rutinadetalles/{eliminarRutinaDetalles.IdRutinaDetalle}");
                        Frame.Content = null;
                        Frame.Navigate(typeof(RutinaDetallesPage));

                    }

                    break;

                default:

                    break;

            }
        }
    }
}
