﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using FitnessLife_SO_UWP.ViewModels;
using FitnessLife_SO_UWP.Views.DietaDetallesViews;
using Newtonsoft.Json;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace FitnessLife_SO_UWP.Views
{
    public sealed partial class DietaDetallesPage : Page
    {
        public DietaDetalles ViewModel { get; } = new DietaDetalles();

        public DietaDetallesPage()
        {
            InitializeComponent();
        }
        
        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
            //base.OnNavigatedTo(e);

            //await ViewModel.LoadDataAsync();
            await mostrarDatos();
        }

        public async Task mostrarDatos()
        {
            var httpHandler = new HttpClientHandler();
            var request = new HttpRequestMessage();
            request.RequestUri = new Uri("https://localhost:44396/api/dietadetalles");
            request.Method = HttpMethod.Get;
            request.Headers.Add("accept", "application/json");

            var client = new HttpClient(httpHandler);

            HttpResponseMessage response = await client.SendAsync(request);

            string content = await response.Content.ReadAsStringAsync();
            var resultado = JsonConvert.DeserializeObject<List<DietaDetalles>>(content);
            Lista.ItemsSource = resultado;

        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            switch ((sender as Button).Content.ToString())

            {

                case "Crear":

                    Frame.Content = null;
                    Frame.Navigate(typeof(CrearDietaDetalles));

                    break;

                case "Modificar":

                    DietaDetalles modificarDietaDetalles = (DietaDetalles)Lista.SelectedItem;
                    if(modificarDietaDetalles != null)
                    {
                        modificarDietaDetalles.Dietas = null;
                        Frame.Content = null;
                        Frame.Navigate(typeof(ModificarDietaDetalles), modificarDietaDetalles.IdDietaDetalle);
                    }
                    
                    break;

                case "Eliminar":

                    DietaDetalles eliminarDietaDetalles = (DietaDetalles)Lista.SelectedItem;
                    if(eliminarDietaDetalles != null)
                    {
                        eliminarDietaDetalles.Dietas = null;
                        var httpHandler = new HttpClientHandler();
                        var client = new HttpClient(httpHandler);
                        var json = JsonConvert.SerializeObject(eliminarDietaDetalles);
                        var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
                        HttpResponseMessage response = await client.DeleteAsync($"https://localhost:44396/api/dietadetalles/{eliminarDietaDetalles.IdDietaDetalle}");
                        Frame.Content = null;
                        Frame.Navigate(typeof(DietaDetallesPage));

                    }
                    
                    

                    break;

                default:

                    break;

            }
        }

        
    }
}
